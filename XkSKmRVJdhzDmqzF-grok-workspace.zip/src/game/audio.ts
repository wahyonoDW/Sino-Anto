type AudioWindow = Window & { webkitAudioContext?: typeof AudioContext };

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let musicBus: GainNode | null = null;
let sfxBus: GainNode | null = null;
let musicTimer: number | null = null;
let musicWanted = false;
let step = 0;

const SCALE = [523.25, 587.33, 659.25, 783.99, 659.25, 587.33, 523.25, 440];

function ensure() {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AudioCtor = window.AudioContext || (window as AudioWindow).webkitAudioContext;
    if (!AudioCtor) return null;
    ctx = new AudioCtor();
    master = ctx.createGain();
    musicBus = ctx.createGain();
    sfxBus = ctx.createGain();
    master.gain.value = 1;
    musicBus.gain.value = 1;
    sfxBus.gain.value = 1;
    musicBus.connect(master);
    sfxBus.connect(master);
    master.connect(ctx.destination);
  }
  return ctx;
}

export function unlockAudio() {
  const audio = ensure();
  if (audio && audio.state === "suspended") void audio.resume();
}

function tone(
  freq: number,
  when: number,
  duration: number,
  volume: number,
  type: OscillatorType,
  bus: GainNode,
) {
  if (!ctx) return;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, when);
  gain.gain.setValueAtTime(0.0001, when);
  gain.gain.exponentialRampToValueAtTime(Math.max(volume, 0.0001), when + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, when + duration);
  osc.connect(gain);
  gain.connect(bus);
  osc.start(when);
  osc.stop(when + duration + 0.03);
  osc.onended = () => {
    osc.disconnect();
    gain.disconnect();
  };
}

export function playCorrect() {
  const audio = ensure();
  if (!audio || !sfxBus) return;
  const now = audio.currentTime;
  tone(523.25, now, 0.12, 0.07, "triangle", sfxBus);
  tone(659.25, now + 0.09, 0.16, 0.07, "triangle", sfxBus);
}

export function playWrong() {
  const audio = ensure();
  if (!audio || !sfxBus) return;
  const now = audio.currentTime;
  tone(220, now, 0.16, 0.05, "sine", sfxBus);
  tone(164.81, now + 0.1, 0.2, 0.05, "sine", sfxBus);
}

export function playBadge() {
  const audio = ensure();
  const bus = sfxBus;
  if (!audio || !bus) return;
  const now = audio.currentTime;
  [523.25, 659.25, 783.99, 1046.5].forEach((freq, index) => {
    tone(freq, now + index * 0.11, 0.2, 0.06, "triangle", bus);
  });
}

function loopMusic() {
  if (!musicWanted || !ctx || !musicBus) return;
  const freq = SCALE[step % SCALE.length] ?? 523.25;
  step += 1;
  tone(freq, ctx.currentTime, 0.34, 0.016, "triangle", musicBus);
  if (step % 4 === 0) tone(freq / 2, ctx.currentTime, 0.4, 0.008, "sine", musicBus);
  musicTimer = window.setTimeout(loopMusic, 700);
}

export function startMusic() {
  musicWanted = true;
  unlockAudio();
  if (musicTimer != null) return;
  loopMusic();
}

export function stopMusic() {
  musicWanted = false;
  if (musicTimer != null) {
    window.clearTimeout(musicTimer);
    musicTimer = null;
  }
}

export function setAudible(on: boolean) {
  unlockAudio();
  if (!ctx || !master) return;
  const now = ctx.currentTime;
  master.gain.cancelScheduledValues(now);
  master.gain.setTargetAtTime(on ? 1 : 0.0001, now, 0.03);
  if (on) startMusic();
  else stopMusic();
}
