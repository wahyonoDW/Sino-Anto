export type LevelId = 1 | 2 | 3 | 4;

export type Area = {
  id: LevelId;
  name: string;
  trail: string;
  lessonTitle: string;
  lesson: string;
  examples: string[];
  image: string;
  imageAlt: string;
  badge: string;
  badgeLine: string;
};

export const AREAS: Area[] = [
  {
    id: 1,
    name: "Desa Sinonim",
    trail: "Materi dan soal sinonim",
    lessonTitle: "Apa itu sinonim?",
    lesson: "Sinonim adalah kata yang memiliki arti sama atau hampir sama.",
    examples: ["pintar = pandai", "senang = gembira", "indah = elok"],
    image: "/art/desa.jpg",
    imageAlt: "Jalan desa dengan rumah kayu dan pohon pisang",
    badge: "Pemburu Sinonim",
    badgeLine: "Kamu lihai mencari kata yang artinya sama.",
  },
  {
    id: 2,
    name: "Hutan Antonim",
    trail: "Materi dan soal antonim",
    lessonTitle: "Apa itu antonim?",
    lesson: "Antonim adalah kata yang memiliki arti berlawanan.",
    examples: ["besar ↔ kecil", "tinggi ↔ rendah", "rajin ↔ malas"],
    image: "/art/hutan.jpg",
    imageAlt: "Jalan setapak di hutan yang terang",
    badge: "Penakluk Antonim",
    badgeLine: "Kamu bisa menemukan lawan kata dengan tepat.",
  },
  {
    id: 3,
    name: "Jembatan Kata",
    trail: "Soal sinonim dan antonim bercampur",
    lessonTitle: "Hati-hati di jembatan",
    lesson:
      "Di area ini soal sinonim dan antonim bercampur. Sinonim artinya sama. Antonim artinya berlawanan. Bacalah perintahnya pelan-pelan.",
    examples: ["pintar = pandai (sinonim)", "besar ↔ kecil (antonim)", "cepat = lekas (sinonim)"],
    image: "/art/jembatan.jpg",
    imageAlt: "Jembatan kayu di atas sungai berbatu",
    badge: "Penjelajah Kata",
    badgeLine: "Kamu bisa membedakan sinonim dan antonim.",
  },
  {
    id: 4,
    name: "Istana Kata",
    trail: "Tantangan akhir di dalam kalimat",
    lessonTitle: "Kata di dalam kalimat",
    lesson:
      "Di istana, kata ada di dalam cerita. Bacalah kalimatnya dulu, lalu lihat apakah soal meminta sinonim atau antonim.",
    examples: ["rajin belajar ↔ malas", "pemandangan indah = elok", "hemat uang = irit"],
    image: "/art/istana.jpg",
    imageAlt: "Istana batu kecil di atas bukit hijau",
    badge: "Ahli Bahasa",
    badgeLine: "Kamu menyelesaikan tantangan paling sulit.",
  },
];

export function areaById(level: number): Area {
  const area = AREAS[level - 1];
  if (!area) throw new Error(`Area ${level} tidak ada`);
  return area;
}
