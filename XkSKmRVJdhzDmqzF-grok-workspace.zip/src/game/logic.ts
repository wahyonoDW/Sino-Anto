import type { Question } from "@/game/questions";

export type Prepared = Omit<Question, "options" | "answer"> & {
  options: string[];
  answer: number;
};

export function shuffle<T>(list: readonly T[]): T[] {
  const arr = [...list];
  for (let i = arr.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    const current = arr[i];
    const swap = arr[j];
    if (current === undefined || swap === undefined) continue;
    arr[i] = swap;
    arr[j] = current;
  }
  return arr;
}

export function prepare(question: Question): Prepared {
  const pairs = question.options.map((text, index) => ({
    text,
    ok: index === question.answer,
  }));
  const mixed = shuffle(pairs);
  const answer = mixed.findIndex((item) => item.ok);
  if (answer < 0) throw new Error(`Kunci soal ${question.id} hilang`);
  return {
    ...question,
    options: mixed.map((item) => item.text),
    answer,
  };
}

export function applyAnswer(streak: number, wrongStreak: number, correct: boolean) {
  if (correct) {
    const nextStreak = streak + 1;
    const bonus = nextStreak % 3 === 0 ? 5 : 0;
    return {
      streak: nextStreak,
      wrongStreak: 0,
      bonus,
      penalty: 0,
      delta: 10 + bonus,
    };
  }
  const nextWrong = wrongStreak + 1;
  const penalty = nextWrong % 3 === 0 ? 5 : 0;
  return {
    streak: 0,
    wrongStreak: nextWrong,
    bonus: 0,
    penalty,
    delta: -penalty,
  };
}

export function shownScore(committed: number, run: number) {
  return committed + Math.max(0, run);
}

export function percentOf(correct: number, total: number) {
  if (total <= 0) return 0;
  return Math.round((correct / total) * 100);
}

export function rankFor(percent: number) {
  if (percent >= 90) {
    return {
      title: "Ahli Kata",
      line: "Kamu sangat menguasai sinonim dan antonim. Hebat!",
    };
  }
  if (percent >= 75) {
    return {
      title: "Jago Kata",
      line: "Pemahamanmu sudah kuat. Pertahankan terus!",
    };
  }
  if (percent >= 60) {
    return {
      title: "Penjelajah Kata",
      line: "Kamu sudah paham dasarnya. Ayo asah lagi!",
    };
  }
  return {
    title: "Terus Berlatih",
    line: "Tidak apa-apa. Ulangi petualangan dan baca penjelasannya.",
  };
}

export const LETTERS = ["A", "B", "C", "D"] as const;
