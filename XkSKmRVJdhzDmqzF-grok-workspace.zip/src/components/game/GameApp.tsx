import { useEffect, useReducer, useRef, type ReactNode } from "react";
import {
  BookOpen,
  Castle,
  Check,
  Compass,
  Flame,
  Home,
  House,
  Lightbulb,
  Lock,
  LockOpen,
  Map,
  RotateCcw,
  Sparkles,
  Sprout,
  Star,
  Trees,
  Trophy,
  Volume2,
  VolumeX,
  X,
  Zap,
  type LucideIcon,
} from "lucide-react";
import { clsx } from "clsx";
import { AREAS, areaById, type LevelId } from "@/game/areas";
import { KIND_LABEL, QUESTIONS } from "@/game/questions";
import {
  LETTERS,
  applyAnswer,
  percentOf,
  prepare,
  rankFor,
  shownScore,
  shuffle,
  type Prepared,
} from "@/game/logic";
import { playBadge, playCorrect, playWrong, setAudible, unlockAudio } from "@/game/audio";

const AREA_ICONS: LucideIcon[] = [House, Trees, Compass, Castle];
const BADGE_ICONS: LucideIcon[] = [Sparkles, Zap, Compass, Trophy];

type Phase = "home" | "map" | "lesson" | "quiz" | "badge" | "finale" | "practice-done";
type ModalName = null | "how" | "hint" | "reset" | "leave-home" | "leave-map";

type State = {
  phase: Phase;
  started: boolean;
  level: LevelId;
  cleared: [boolean, boolean, boolean, boolean];
  score: number;
  correct: number;
  wrong: number;
  levelPoints: [number, number, number, number];
  levelHits: [number, number, number, number];
  deck: Prepared[];
  index: number;
  picked: number | null;
  streak: number;
  wrongStreak: number;
  runScore: number;
  runCorrect: number;
  runWrong: number;
  lastBonus: number;
  lastPenalty: number;
  practice: boolean;
  justAwarded: boolean;
  soundOn: boolean;
  modal: ModalName;
  burst: number;
};

type Action =
  | { type: "start" }
  | { type: "ask-leave"; target: "home" | "map" }
  | { type: "confirm-leave" }
  | { type: "how" }
  | { type: "hint" }
  | { type: "ask-reset" }
  | { type: "close-modal" }
  | { type: "open-level"; level: LevelId }
  | { type: "begin-quiz" }
  | { type: "practice" }
  | { type: "pick"; index: number }
  | { type: "next" }
  | { type: "finale" }
  | { type: "reset" }
  | { type: "sound" };

function runs() {
  return {
    deck: [] as Prepared[],
    index: 0,
    picked: null as number | null,
    streak: 0,
    wrongStreak: 0,
    runScore: 0,
    runCorrect: 0,
    runWrong: 0,
    lastBonus: 0,
    lastPenalty: 0,
    burst: 0,
  };
}

function initialState(): State {
  return {
    phase: "home",
    started: false,
    level: 1,
    cleared: [false, false, false, false],
    score: 0,
    correct: 0,
    wrong: 0,
    levelPoints: [0, 0, 0, 0],
    levelHits: [0, 0, 0, 0],
    practice: false,
    justAwarded: false,
    soundOn: true,
    modal: null,
    ...runs(),
  };
}

function unlocked(cleared: readonly boolean[], level: number) {
  return level === 1 || cleared[level - 2] === true;
}

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case "start":
      return { ...state, phase: "map", started: true, modal: null };
    case "ask-leave":
      if (state.phase === "quiz") {
        return { ...state, modal: action.target === "home" ? "leave-home" : "leave-map" };
      }
      if (action.target === "home") return { ...state, phase: "home", modal: null, ...runs() };
      return { ...state, phase: "map", started: true, modal: null, ...runs() };
    case "confirm-leave":
      if (state.modal === "leave-home") return { ...state, phase: "home", modal: null, ...runs() };
      return { ...state, phase: "map", started: true, modal: null, ...runs() };
    case "how":
      return { ...state, modal: "how" };
    case "hint":
      return { ...state, modal: state.phase === "quiz" ? "hint" : "how" };
    case "ask-reset":
      return { ...state, modal: "reset" };
    case "close-modal":
      return { ...state, modal: null };
    case "open-level": {
      if (!unlocked(state.cleared, action.level)) return state;
      if (state.cleared[action.level - 1]) {
        return {
          ...state,
          phase: "badge",
          level: action.level,
          practice: false,
          justAwarded: false,
          modal: null,
        };
      }
      return {
        ...state,
        phase: "lesson",
        level: action.level,
        practice: false,
        justAwarded: false,
        modal: null,
      };
    }
    case "begin-quiz": {
      const deck = shuffle(QUESTIONS.filter((item) => item.level === state.level)).map(prepare);
      return { ...state, phase: "quiz", ...runs(), deck, modal: null };
    }
    case "practice":
      return { ...state, practice: true, justAwarded: false, phase: "lesson", modal: null };
    case "pick": {
      if (state.picked !== null) return state;
      const question = state.deck[state.index];
      if (!question || action.index < 0 || action.index > 3) return state;
      const ok = action.index === question.answer;
      const result = applyAnswer(state.streak, state.wrongStreak, ok);
      return {
        ...state,
        picked: action.index,
        streak: result.streak,
        wrongStreak: result.wrongStreak,
        runScore: state.runScore + result.delta,
        runCorrect: state.runCorrect + (ok ? 1 : 0),
        runWrong: state.runWrong + (ok ? 0 : 1),
        lastBonus: result.bonus,
        lastPenalty: result.penalty,
        burst: ok ? state.burst + 1 : state.burst,
      };
    }
    case "next": {
      if (state.picked === null) return state;
      const last = state.index >= state.deck.length - 1;
      if (!last) {
        return { ...state, index: state.index + 1, picked: null, lastBonus: 0, lastPenalty: 0 };
      }
      if (state.practice) return { ...state, phase: "practice-done", modal: null };
      const slot = state.level - 1;
      const cleared = [...state.cleared] as State["cleared"];
      const levelPoints = [...state.levelPoints] as State["levelPoints"];
      const levelHits = [...state.levelHits] as State["levelHits"];
      const earned = Math.max(0, state.runScore);
      const firstClear = !cleared[slot];
      cleared[slot] = true;
      levelPoints[slot] = earned;
      levelHits[slot] = state.runCorrect;
      const score = levelPoints.reduce((sum, points) => sum + points, 0);
      return {
        ...state,
        phase: "badge",
        modal: null,
        justAwarded: true,
        cleared,
        levelPoints,
        levelHits,
        score,
        correct: firstClear ? state.correct + state.runCorrect : state.correct,
        wrong: firstClear ? state.wrong + state.runWrong : state.wrong,
      };
    }
    case "finale":
      return { ...state, phase: "finale", modal: null };
    case "reset":
      return { ...initialState(), soundOn: state.soundOn };
    case "sound":
      return { ...state, soundOn: !state.soundOn };
    default: {
      const unreachable: never = action;
      return unreachable;
    }
  }
}

function useGame() {
  const [state, dispatch] = useReducer(reducer, undefined, initialState);
  const stateRef = useRef(state);
  stateRef.current = state;

  useEffect(() => {
    function onVis() {
      if (document.visibilityState === "visible" && stateRef.current.soundOn) unlockAudio();
    }
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, []);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const current = stateRef.current;
      if (current.modal) {
        if (event.key === "Escape") dispatch({ type: "close-modal" });
        return;
      }
      if (current.phase !== "quiz" || current.picked !== null) return;
      const key = event.key.toLowerCase();
      const map: Record<string, number> = { "1": 0, "2": 1, "3": 2, "4": 3, a: 0, b: 1, c: 2, d: 3 };
      const index = map[key];
      if (index === undefined) return;
      event.preventDefault();
      choose(index);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (state.phase !== "quiz") return;
    const id = state.picked === null ? "soal-judul" : "lanjut";
    document.getElementById(id)?.focus();
  }, [state.phase, state.index, state.picked]);

  function wake() {
    unlockAudio();
    if (state.soundOn) setAudible(true);
  }

  function choose(index: number) {
    const current = stateRef.current;
    const question = current.deck[current.index];
    if (!question || current.picked !== null) return;
    unlockAudio();
    if (current.soundOn) {
      if (index === question.answer) playCorrect();
      else playWrong();
    }
    dispatch({ type: "pick", index });
  }

  function finishOrNext() {
    const current = stateRef.current;
    const last = current.index >= current.deck.length - 1;
    if (last && !current.practice && current.soundOn) playBadge();
    dispatch({ type: "next" });
  }

  return { state, dispatch, wake, choose, finishOrNext };
}

export function GameApp() {
  const { state, dispatch, wake, choose, finishOrNext } = useGame();
  const area = areaById(state.level);
  const doneCount = state.cleared.filter(Boolean).length;
  const question = state.deck[state.index];
  const totalBank = QUESTIONS.length;

  return (
    <div className="min-h-dvh text-ink">
      <header className="sticky top-0 z-20 border-b border-line bg-paper/95 backdrop-blur-sm">
        <div className="mx-auto flex w-full max-w-5xl flex-col gap-3 px-4 py-3">
          <div className="flex items-center gap-3">
            <img
              src="/logo-sekolah.png"
              alt="Logo SD Negeri Kalisari"
              className="h-12 w-12 shrink-0 object-contain"
            />
            <div className="min-w-0">
              <p className="font-display text-lg leading-tight">Petualangan Kata</p>
              <p className="truncate text-sm text-muted">SD Negeri Kalisari · Kecamatan Reban</p>
            </div>
          </div>
          <nav className="flex flex-wrap gap-2" aria-label="Menu permainan">
            <NavButton
              label="Beranda"
              icon={Home}
              onClick={() => {
                wake();
                dispatch({ type: "ask-leave", target: "home" });
              }}
            />
            <NavButton
              label="Peta"
              icon={Map}
              onClick={() => {
                wake();
                dispatch({ type: "ask-leave", target: "map" });
              }}
            />
            <NavButton
              label={state.phase === "quiz" ? "Petunjuk" : "Cara main"}
              icon={Lightbulb}
              onClick={() => {
                wake();
                dispatch({ type: "hint" });
              }}
            />
            <NavButton
              label={state.soundOn ? "Suara nyala" : "Suara mati"}
              icon={state.soundOn ? Volume2 : VolumeX}
              pressed={state.soundOn}
              onClick={() => {
                const next = !state.soundOn;
                if (next) setAudible(true);
                else setAudible(false);
                dispatch({ type: "sound" });
              }}
            />
            <NavButton
              label="Ulangi"
              icon={RotateCcw}
              onClick={() => {
                wake();
                dispatch({ type: "ask-reset" });
              }}
            />
          </nav>
        </div>
      </header>

      <main className="mx-auto w-full max-w-5xl px-4 py-6">
        {state.phase === "home" ? (
          <HomeScreen
            started={state.started}
            onStart={() => {
              wake();
              dispatch({ type: "start" });
            }}
            onHow={() => {
              wake();
              dispatch({ type: "how" });
            }}
          />
        ) : null}

        {state.phase === "map" ? (
          <MapScreen
            cleared={state.cleared}
            doneCount={doneCount}
            score={state.score}
            onOpen={(level) => {
              wake();
              dispatch({ type: "open-level", level });
            }}
            onFinale={() => {
              wake();
              dispatch({ type: "finale" });
            }}
          />
        ) : null}

        {state.phase === "lesson" ? (
          <LessonScreen
            level={state.level}
            practice={state.practice}
            onBegin={() => {
              wake();
              dispatch({ type: "begin-quiz" });
            }}
          />
        ) : null}

        {state.phase === "quiz" && question ? (
          <QuizScreen
            state={state}
            question={question}
            onPick={(index) => {
              wake();
              choose(index);
            }}
            onNext={() => {
              wake();
              finishOrNext();
            }}
          />
        ) : null}

        {state.phase === "badge" ? (
          <BadgeScreen
            level={state.level}
            hits={state.justAwarded ? state.runCorrect : state.levelHits[state.level - 1]}
            points={state.justAwarded ? Math.max(0, state.runScore) : state.levelPoints[state.level - 1]}
            fresh={state.justAwarded}
            allDone={doneCount === 4}
            onMap={() => {
              wake();
              dispatch({ type: "ask-leave", target: "map" });
            }}
            onPractice={() => {
              wake();
              dispatch({ type: "practice" });
            }}
            onFinale={() => {
              wake();
              dispatch({ type: "finale" });
            }}
          />
        ) : null}

        {state.phase === "practice-done" ? (
          <PracticeDone
            level={state.level}
            hits={state.runCorrect}
            points={Math.max(0, state.runScore)}
            onMap={() => {
              wake();
              dispatch({ type: "ask-leave", target: "map" });
            }}
          />
        ) : null}

        {state.phase === "finale" ? (
          <FinaleScreen
            score={state.score}
            correct={state.correct}
            wrong={state.wrong}
            total={totalBank}
            onAgain={() => {
              wake();
              dispatch({ type: "reset" });
            }}
            onMap={() => {
              wake();
              dispatch({ type: "ask-leave", target: "map" });
            }}
          />
        ) : null}
      </main>

      {state.modal ? (
        <Modal
          title={modalTitle(state.modal)}
          onClose={() => dispatch({ type: "close-modal" })}
        >
          <ModalBody
            name={state.modal}
            hint={question?.hint ?? area.lesson}
            onClose={() => dispatch({ type: "close-modal" })}
            onReset={() => {
              if (!state.soundOn) setAudible(false);
              dispatch({ type: "reset" });
            }}
            onLeave={() => dispatch({ type: "confirm-leave" })}
          />
        </Modal>
      ) : null}
    </div>
  );
}

function NavButton({
  label,
  icon: Icon,
  onClick,
  pressed,
}: {
  label: string;
  icon: LucideIcon;
  onClick: () => void;
  pressed?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      aria-pressed={pressed}
      className="inline-flex min-h-11 min-w-11 items-center justify-center gap-2 rounded-xl border border-line bg-card px-2 text-sm font-semibold text-ink active:scale-95 sm:px-3"
    >
      <Icon className="size-5 shrink-0" aria-hidden="true" />
      <span className="max-sm:sr-only">{label}</span>
    </button>
  );
}

function HomeScreen({
  started,
  onStart,
  onHow,
}: {
  started: boolean;
  onStart: () => void;
  onHow: () => void;
}) {
  return (
    <section className="rise grid items-center gap-6 lg:grid-cols-2">
      <div>
        <p className="text-sm font-semibold tracking-wide text-amber uppercase">Misi Sinonim & Antonim</p>
        <h1 className="mt-2 font-display text-4xl leading-tight text-ink sm:text-5xl">
          Petualangan Kata
        </h1>
        <p className="mt-3 max-w-xl text-lg text-ink">
          Belajar Sinonim dan Antonim sambil Berpetualang!
        </p>
        <div className="mt-5 flex flex-col gap-3 sm:flex-row">
          <button
            type="button"
            onClick={onStart}
            className="inline-flex min-h-12 items-center justify-center rounded-2xl bg-forest px-6 text-base font-semibold text-on-forest active:scale-95"
          >
            {started ? "Lanjutkan Petualangan" : "Mulai Petualangan"}
          </button>
          <button
            type="button"
            onClick={onHow}
            className="inline-flex min-h-12 items-center justify-center rounded-2xl border border-line bg-card px-6 text-base font-semibold text-ink active:scale-95"
          >
            Cara Bermain
          </button>
        </div>
        <p className="mt-4 max-w-xl text-muted">
          Empat area menanti: desa, hutan, jembatan, dan istana. Setiap area punya 10 soal.
        </p>
      </div>
      <figure className="panel overflow-hidden">
        <img
          src="/art/hero.jpg"
          alt="Dua anak membawa peta melewati desa, hutan, jembatan, dan istana"
          className="aspect-video w-full object-cover"
        />
      </figure>
    </section>
  );
}

function MapScreen({
  cleared,
  doneCount,
  score,
  onOpen,
  onFinale,
}: {
  cleared: readonly boolean[];
  doneCount: number;
  score: number;
  onOpen: (level: LevelId) => void;
  onFinale: () => void;
}) {
  return (
    <section className="rise">
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl">Peta Petualangan</h1>
          <p className="text-muted">Selesaikan satu area untuk membuka area berikutnya.</p>
        </div>
        <p className="rounded-full bg-card px-4 py-2 text-sm font-semibold">Skor: {score}</p>
      </div>
      <Bar value={doneCount} max={4} label="Progress keseluruhan" />
      {doneCount === 4 ? (
        <button
          type="button"
          onClick={onFinale}
          className="mt-4 inline-flex min-h-12 w-full items-center justify-center rounded-2xl bg-amber px-5 font-semibold text-on-forest active:scale-95 sm:w-auto"
        >
          Lihat hasil petualangan
        </button>
      ) : null}
      <ol className="mt-5 grid gap-4 lg:grid-cols-2">
        {AREAS.map((area) => {
          const locked = !unlocked(cleared, area.id);
          const done = cleared[area.id - 1] === true;
          const Icon = AREA_ICONS[area.id - 1] ?? BookOpen;
          const status = done ? "Selesai" : locked ? "Terkunci" : "Terbuka";
          return (
            <li key={area.id} className="panel overflow-hidden">
              <img src={area.image} alt={area.imageAlt} className="aspect-video w-full object-cover" />
              <div className="flex flex-col gap-3 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold text-amber">Area {area.id}</p>
                    <h2 className="font-display text-2xl">{area.name}</h2>
                    <p className="text-sm text-muted">{area.trail}</p>
                  </div>
                  <span
                    className={clsx(
                      "inline-flex shrink-0 items-center gap-1 rounded-full px-3 py-1 text-sm font-semibold",
                      done && "bg-good-soft text-good",
                      !done && !locked && "bg-amber-soft text-amber",
                      locked && "bg-paper-deep text-muted",
                    )}
                  >
                    {done ? <Star className="size-4" aria-hidden="true" /> : null}
                    {locked ? <Lock className="size-4" aria-hidden="true" /> : null}
                    {!done && !locked ? <LockOpen className="size-4" aria-hidden="true" /> : null}
                    {status}
                  </span>
                </div>
                <button
                  type="button"
                  disabled={locked}
                  onClick={() => onOpen(area.id)}
                  className="inline-flex min-h-12 items-center justify-center gap-2 rounded-2xl bg-forest px-4 font-semibold text-on-forest active:scale-95 disabled:bg-paper-deep disabled:text-muted"
                >
                  <Icon className="size-5" aria-hidden="true" />
                  {locked ? "Masih terkunci" : done ? "Lihat lencana" : "Mulai area"}
                </button>
              </div>
            </li>
          );
        })}
      </ol>
    </section>
  );
}

function LessonScreen({
  level,
  practice,
  onBegin,
}: {
  level: LevelId;
  practice: boolean;
  onBegin: () => void;
}) {
  const area = areaById(level);
  return (
    <section className="rise mx-auto max-w-2xl">
      <p className="text-sm font-semibold text-amber">Area {level}</p>
      <h1 className="font-display text-3xl">{area.name}</h1>
      {practice ? (
        <p className="mt-2 rounded-xl bg-amber-soft px-3 py-2 text-sm font-semibold text-amber">
          Mode latihan. Skor resmi tidak berubah.
        </p>
      ) : null}
      <article className="panel mt-4 overflow-hidden">
        <img src={area.image} alt="" className="aspect-video w-full object-cover" />
        <div className="p-5">
          <div className="mb-3 flex items-center gap-2 text-forest">
            <BookOpen className="size-5" aria-hidden="true" />
            <h2 className="font-display text-2xl text-ink">{area.lessonTitle}</h2>
          </div>
          <p className="text-lg">{area.lesson}</p>
          <ul className="mt-4 grid gap-2">
            {area.examples.map((example) => (
              <li key={example} className="rounded-xl bg-amber-soft px-4 py-3 font-semibold text-ink">
                {example}
              </li>
            ))}
          </ul>
          <button
            type="button"
            onClick={onBegin}
            className="mt-5 inline-flex min-h-12 w-full items-center justify-center rounded-2xl bg-forest px-5 font-semibold text-on-forest active:scale-95"
          >
            Saya Mengerti, Mulai Soal
          </button>
        </div>
      </article>
    </section>
  );
}

function QuizScreen({
  state,
  question,
  onPick,
  onNext,
}: {
  state: State;
  question: Prepared;
  onPick: (index: number) => void;
  onNext: () => void;
}) {
  const area = areaById(state.level);
  const answered = state.picked !== null;
  const correct = answered && state.picked === question.answer;
  const score = state.practice
    ? Math.max(0, state.runScore)
    : shownScore(state.score, state.runScore);
  const progress = state.index + (answered ? 1 : 0);
  const last = state.index >= state.deck.length - 1;
  const answerText = question.options[question.answer] ?? "";

  return (
    <section className="mx-auto max-w-3xl">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <h1 className="font-display text-2xl">{area.name}</h1>
        <p className="rounded-full bg-card px-3 py-1 text-sm font-semibold text-amber">
          {KIND_LABEL[question.kind]}
        </p>
      </div>
      {state.practice ? (
        <p className="mb-3 text-sm font-semibold text-amber">Mode latihan — skor resmi tidak berubah.</p>
      ) : null}
      <div className="mb-4 grid grid-cols-3 gap-2">
        <Stat label="Skor" value={String(score)} />
        <Stat label="Benar" value={`${state.runCorrect}/10`} />
        <Stat
          label="Streak"
          value={String(state.streak)}
          icon={state.streak > 0 ? <Flame className="size-4 text-amber" aria-hidden="true" /> : null}
        />
      </div>
      <Bar value={progress} max={10} label="Soal di area ini" />
      <article className="panel relative mt-4 p-4 sm:p-6">
        {correct ? (
          <div key={state.burst} className="burst" aria-hidden="true">
            {Array.from({ length: 6 }, (_, index) => (
              <Star key={index} className="size-5 fill-amber" strokeWidth={1.5} />
            ))}
          </div>
        ) : null}
        <p className="text-sm font-semibold text-muted">Soal {state.index + 1} dari 10</p>
        <h2 id="soal-judul" tabIndex={-1} className="rise mt-1 font-display text-2xl leading-snug">
          {question.prompt}
        </h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2" role="group" aria-label="Pilihan jawaban">
          {question.options.map((option, index) => {
            const letter = LETTERS[index] ?? "";
            const isAnswer = index === question.answer;
            const isPick = index === state.picked;
            return (
              <button
                key={option}
                type="button"
                disabled={answered}
                onClick={() => onPick(index)}
                className={clsx(
                  "flex min-h-14 items-center gap-3 rounded-2xl border px-3 py-3 text-left text-base font-semibold active:scale-95 disabled:opacity-100",
                  !answered && "border-line bg-card",
                  answered && isAnswer && "border-good bg-good-soft",
                  answered && isPick && !isAnswer && "border-bad bg-bad-soft",
                  answered && !isAnswer && !isPick && "border-line bg-card text-muted",
                )}
              >
                <span
                  className={clsx(
                    "inline-flex size-11 shrink-0 items-center justify-center rounded-full",
                    answered && isAnswer ? "bg-good text-on-forest" : "bg-paper-deep text-ink",
                  )}
                  aria-hidden="true"
                >
                  {letter}
                </span>
                <span className="flex-1">{option}</span>
                {answered && isAnswer ? <Check className="size-5 text-good" aria-hidden="true" /> : null}
                {answered && isPick && !isAnswer ? <X className="size-5 text-bad" aria-hidden="true" /> : null}
              </button>
            );
          })}
        </div>
        <p className="mt-3 text-sm text-muted">Di komputer, tekan A sampai D untuk menjawab.</p>
        {answered ? (
          <div
            aria-live="polite"
            className={clsx("mt-4 rounded-2xl px-4 py-3", correct ? "bg-good-soft" : "bg-bad-soft")}
          >
            <p className="font-semibold">{correct ? "🎉 Hebat! Jawabanmu benar!" : "Belum tepat. Yuk, coba pahami lagi!"}</p>
            {!correct ? <p className="mt-1">Jawaban yang benar: {answerText}.</p> : null}
            <p className="mt-1">{question.explanation}</p>
            {state.lastBonus > 0 ? (
              <p className="mt-2 font-semibold text-good">Bonus 3 benar berturut-turut: +5 poin.</p>
            ) : null}
            {state.lastPenalty > 0 ? (
              <p className="mt-2 font-semibold text-bad">Tiga salah berturut-turut: −5 poin.</p>
            ) : null}
            <button
              id="lanjut"
              type="button"
              onClick={onNext}
              className="mt-3 inline-flex min-h-12 w-full items-center justify-center rounded-2xl bg-forest px-5 font-semibold text-on-forest active:scale-95 sm:w-auto"
            >
              {last ? (state.practice ? "Selesai latihan" : "Lihat lencana") : "Lanjut"}
            </button>
          </div>
        ) : (
          <p className="sr-only" aria-live="polite">
            Pilih satu jawaban.
          </p>
        )}
      </article>
    </section>
  );
}

function Stat({ label, value, icon }: { label: string; value: string; icon?: ReactNode }) {
  return (
    <div className="rounded-2xl border border-line bg-card px-3 py-2">
      <p className="text-xs font-semibold tracking-wide text-muted uppercase">{label}</p>
      <p className="flex items-center gap-1 font-display text-2xl">
        {value}
        {icon}
      </p>
    </div>
  );
}

function BadgeScreen({
  level,
  hits,
  points,
  fresh,
  allDone,
  onMap,
  onPractice,
  onFinale,
}: {
  level: LevelId;
  hits: number;
  points: number;
  fresh: boolean;
  allDone: boolean;
  onMap: () => void;
  onPractice: () => void;
  onFinale: () => void;
}) {
  const area = areaById(level);
  const Icon = BADGE_ICONS[level - 1] ?? Trophy;
  return (
    <section className="rise mx-auto max-w-xl text-center">
      <div className="panel px-5 py-8">
        <div className="pop mx-auto flex size-24 items-center justify-center rounded-full bg-amber-soft text-amber">
          <Icon className="size-12" aria-hidden="true" />
        </div>
        <p className="mt-4 text-sm font-semibold text-amber">{fresh ? "Lencana baru" : "Lencana terkumpul"}</p>
        <h1 className="font-display text-3xl">{area.badge}</h1>
        <p className="mt-2 text-muted">{area.badgeLine}</p>
        <dl className="mt-5 grid grid-cols-2 gap-3 text-left">
          <div className="rounded-2xl bg-paper px-3 py-3">
            <dt className="text-sm text-muted">Benar</dt>
            <dd className="font-display text-2xl">{hits}/10</dd>
          </div>
          <div className="rounded-2xl bg-paper px-3 py-3">
            <dt className="text-sm text-muted">Poin area</dt>
            <dd className="font-display text-2xl">{points}</dd>
          </div>
        </dl>
        <div className="mt-5 flex flex-col gap-3">
          {fresh && allDone ? (
            <button
              type="button"
              onClick={onFinale}
              className="inline-flex min-h-12 items-center justify-center rounded-2xl bg-forest px-5 font-semibold text-on-forest active:scale-95"
            >
              Lihat hasil
            </button>
          ) : (
            <button
              type="button"
              onClick={onMap}
              className="inline-flex min-h-12 items-center justify-center rounded-2xl bg-forest px-5 font-semibold text-on-forest active:scale-95"
            >
              Kembali ke Peta
            </button>
          )}
          <button
            type="button"
            onClick={onPractice}
            className="inline-flex min-h-12 items-center justify-center rounded-2xl border border-line bg-card px-5 font-semibold active:scale-95"
          >
            Latihan lagi
          </button>
        </div>
      </div>
    </section>
  );
}

function PracticeDone({
  level,
  hits,
  points,
  onMap,
}: {
  level: LevelId;
  hits: number;
  points: number;
  onMap: () => void;
}) {
  const area = areaById(level);
  return (
    <section className="rise mx-auto max-w-xl">
      <article className="panel p-6 text-center">
        <h1 className="font-display text-3xl">Latihan selesai</h1>
        <p className="mt-2 text-muted">
          {area.name}: {hits} dari 10 benar. Skor latihan {points} tidak mengubah nilai resmi.
        </p>
        <button
          type="button"
          onClick={onMap}
          className="mt-5 inline-flex min-h-12 w-full items-center justify-center rounded-2xl bg-forest px-5 font-semibold text-on-forest active:scale-95"
        >
          Kembali ke Peta
        </button>
      </article>
    </section>
  );
}

function FinaleScreen({
  score,
  correct,
  wrong,
  total,
  onAgain,
  onMap,
}: {
  score: number;
  correct: number;
  wrong: number;
  total: number;
  onAgain: () => void;
  onMap: () => void;
}) {
  const percent = percentOf(correct, total);
  const rank = rankFor(percent);
  const RankIcon =
    rank.title === "Ahli Kata"
      ? Trophy
      : rank.title === "Jago Kata"
        ? Star
        : rank.title === "Penjelajah Kata"
          ? Compass
          : Sprout;
  return (
    <section className="rise mx-auto max-w-3xl">
      <div className="text-center">
        <p className="text-sm font-semibold text-amber">Perjalanan usai</p>
        <h1 className="font-display text-4xl">Petualangan Selesai!</h1>
        <p className="mt-2 text-muted">Kamu menempuh empat area sinonim dan antonim.</p>
      </div>
      <article className="panel mt-5 overflow-hidden">
        <img src="/art/istana.jpg" alt="" className="aspect-video w-full object-cover" />
        <div className="grid gap-3 p-5 sm:grid-cols-2">
          <ResultTile label="Total skor" value={String(score)} />
          <ResultTile label="Jawaban benar" value={`${correct}`} />
          <ResultTile label="Jawaban salah" value={`${wrong}`} />
          <ResultTile label="Persentase" value={`${percent}%`} />
        </div>
      </article>
      <article className="panel mt-4 p-5 text-center">
        <div className="pop mx-auto flex size-20 items-center justify-center rounded-full bg-amber-soft text-amber">
          <RankIcon className="size-10" aria-hidden="true" />
        </div>
        <h2 className="mt-3 font-display text-3xl">{rank.title}</h2>
        <p className="mt-1 text-muted">{rank.line}</p>
      </article>
      <h2 className="mt-6 font-display text-2xl">Lencana yang diperoleh</h2>
      <ul className="mt-3 grid gap-3 sm:grid-cols-2">
        {AREAS.map((area) => {
          const Icon = BADGE_ICONS[area.id - 1] ?? Star;
          return (
            <li key={area.id} className="panel flex items-center gap-3 p-4">
              <span className="flex size-12 items-center justify-center rounded-full bg-amber-soft text-amber">
                <Icon className="size-6" aria-hidden="true" />
              </span>
              <span>
                <span className="block text-sm text-muted">{area.name}</span>
                <span className="block font-semibold">{area.badge}</span>
              </span>
            </li>
          );
        })}
      </ul>
      <div className="mt-5 flex flex-col gap-3 sm:flex-row">
        <button
          type="button"
          onClick={onAgain}
          className="inline-flex min-h-12 flex-1 items-center justify-center rounded-2xl bg-forest px-5 font-semibold text-on-forest active:scale-95"
        >
          Main Lagi
        </button>
        <button
          type="button"
          onClick={onMap}
          className="inline-flex min-h-12 flex-1 items-center justify-center rounded-2xl border border-line bg-card px-5 font-semibold active:scale-95"
        >
          Kembali ke Peta
        </button>
      </div>
    </section>
  );
}

function ResultTile({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-paper px-4 py-3">
      <p className="text-sm text-muted">{label}</p>
      <p className="font-display text-3xl">{value}</p>
    </div>
  );
}

function Bar({ value, max, label }: { value: number; max: number; label: string }) {
  const width = max === 0 ? 0 : Math.max(0, Math.min(100, Math.round((value / max) * 100)));
  return (
    <div>
      <div className="mb-1 flex justify-between gap-3 text-sm text-muted">
        <span>{label}</span>
        <span>
          {value}/{max}
        </span>
      </div>
      <div
        className="h-3 overflow-hidden rounded-full bg-paper-deep"
        role="progressbar"
        aria-label={label}
        aria-valuemin={0}
        aria-valuemax={max}
        aria-valuenow={value}
      >
        <div className="bar-fill" style={{ width: `${width}%` }} />
      </div>
    </div>
  );
}

function Modal({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement;
    ref.current?.focus();
    return () => {
      if (previous instanceof HTMLElement) previous.focus();
    };
  }, []);
  return (
    <div
      className="fixed inset-0 z-40 flex items-end justify-center bg-ink/45 p-4 sm:items-center"
      onClick={onClose}
    >
      <div
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-judul"
        tabIndex={-1}
        className="panel max-h-[85dvh] w-full max-w-lg overflow-y-auto p-5"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <h2 id="modal-judul" className="font-display text-2xl">
            {title}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex size-11 items-center justify-center rounded-full bg-paper-deep"
            aria-label="Tutup"
          >
            <X className="size-5" aria-hidden="true" />
          </button>
        </div>
        <div className="mt-3">{children}</div>
      </div>
    </div>
  );
}

function modalTitle(name: Exclude<ModalName, null>) {
  if (name === "how") return "Cara Bermain";
  if (name === "hint") return "Petunjuk";
  if (name === "reset") return "Ulangi permainan?";
  return "Tinggalkan soal?";
}

function ModalBody({
  name,
  hint,
  onClose,
  onReset,
  onLeave,
}: {
  name: Exclude<ModalName, null>;
  hint: string;
  onClose: () => void;
  onReset: () => void;
  onLeave: () => void;
}) {
  if (name === "how") {
    return (
      <ol className="grid list-decimal gap-2 pl-5 text-ink">
        <li>Pilih area di peta. Area berikutnya terbuka setelah area sebelumnya selesai.</li>
        <li>Baca materi singkat, lalu jawab 10 soal. Pilihan dan urutan soal diacak.</li>
        <li>Jawaban benar mendapat 10 poin. Tiga benar berturut-turut menambah bonus 5 poin.</li>
        <li>Tiga salah berturut-turut mengurangi 5 poin. Nyawa tidak dipakai.</li>
        <li>Setiap area memberi satu lencana. Selesaikan Istana Kata untuk melihat hasil.</li>
      </ol>
    );
  }
  if (name === "hint") {
    return (
      <>
        <p>{hint}</p>
        <button
          type="button"
          onClick={onClose}
          className="mt-4 inline-flex min-h-12 w-full items-center justify-center rounded-2xl bg-forest px-5 font-semibold text-on-forest"
        >
          Mengerti
        </button>
      </>
    );
  }
  if (name === "reset") {
    return (
      <>
        <p>Semua skor, lencana, dan area yang sudah selesai akan dihapus. Permainan mulai dari awal.</p>
        <div className="mt-4 flex flex-col gap-2 sm:flex-row">
          <button
            type="button"
            onClick={onReset}
            className="inline-flex min-h-12 flex-1 items-center justify-center rounded-2xl bg-forest px-4 font-semibold text-on-forest"
          >
            Ya, ulangi
          </button>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex min-h-12 flex-1 items-center justify-center rounded-2xl border border-line bg-card px-4 font-semibold"
          >
            Batal
          </button>
        </div>
      </>
    );
  }
  return (
    <>
      <p>Jawaban di area ini belum disimpan. Kamu bisa mulai lagi dari awal area.</p>
      <div className="mt-4 flex flex-col gap-2 sm:flex-row">
        <button
          type="button"
          onClick={onLeave}
          className="inline-flex min-h-12 flex-1 items-center justify-center rounded-2xl bg-forest px-4 font-semibold text-on-forest"
        >
          Ya, tinggalkan
        </button>
        <button
          type="button"
          onClick={onClose}
          className="inline-flex min-h-12 flex-1 items-center justify-center rounded-2xl border border-line bg-card px-4 font-semibold"
        >
          Tetap di soal
        </button>
      </div>
    </>
  );
}
