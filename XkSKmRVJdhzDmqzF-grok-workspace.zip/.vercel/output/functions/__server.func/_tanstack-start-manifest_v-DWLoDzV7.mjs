//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DWLoDzV7.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CxL_2fmZ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CxL_2fmZ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-yIaAUUAx.js"]
	}
} });
//#endregion
export { tsrStartManifest };
