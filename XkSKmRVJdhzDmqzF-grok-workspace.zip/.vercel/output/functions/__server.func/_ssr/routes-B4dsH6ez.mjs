import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Flame, a as Trophy, b as Castle, c as Star, d as RotateCcw, f as Map, g as House, h as Lightbulb, i as Volume2, l as Sprout, m as LockOpen, n as X, p as Lock, r as VolumeX, s as Trees, t as Zap, u as Sparkles, v as Compass, x as BookOpen, y as Check } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B4dsH6ez.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AREAS = [
	{
		id: 1,
		name: "Desa Sinonim",
		trail: "Materi dan soal sinonim",
		lessonTitle: "Apa itu sinonim?",
		lesson: "Sinonim adalah kata yang memiliki arti sama atau hampir sama.",
		examples: [
			"pintar = pandai",
			"senang = gembira",
			"indah = elok"
		],
		image: "/art/desa.jpg",
		imageAlt: "Jalan desa dengan rumah kayu dan pohon pisang",
		badge: "Pemburu Sinonim",
		badgeLine: "Kamu lihai mencari kata yang artinya sama."
	},
	{
		id: 2,
		name: "Hutan Antonim",
		trail: "Materi dan soal antonim",
		lessonTitle: "Apa itu antonim?",
		lesson: "Antonim adalah kata yang memiliki arti berlawanan.",
		examples: [
			"besar ↔ kecil",
			"tinggi ↔ rendah",
			"rajin ↔ malas"
		],
		image: "/art/hutan.jpg",
		imageAlt: "Jalan setapak di hutan yang terang",
		badge: "Penakluk Antonim",
		badgeLine: "Kamu bisa menemukan lawan kata dengan tepat."
	},
	{
		id: 3,
		name: "Jembatan Kata",
		trail: "Soal sinonim dan antonim bercampur",
		lessonTitle: "Hati-hati di jembatan",
		lesson: "Di area ini soal sinonim dan antonim bercampur. Sinonim artinya sama. Antonim artinya berlawanan. Bacalah perintahnya pelan-pelan.",
		examples: [
			"pintar = pandai (sinonim)",
			"besar ↔ kecil (antonim)",
			"cepat = lekas (sinonim)"
		],
		image: "/art/jembatan.jpg",
		imageAlt: "Jembatan kayu di atas sungai berbatu",
		badge: "Penjelajah Kata",
		badgeLine: "Kamu bisa membedakan sinonim dan antonim."
	},
	{
		id: 4,
		name: "Istana Kata",
		trail: "Tantangan akhir di dalam kalimat",
		lessonTitle: "Kata di dalam kalimat",
		lesson: "Di istana, kata ada di dalam cerita. Bacalah kalimatnya dulu, lalu lihat apakah soal meminta sinonim atau antonim.",
		examples: [
			"rajin belajar ↔ malas",
			"pemandangan indah = elok",
			"hemat uang = irit"
		],
		image: "/art/istana.jpg",
		imageAlt: "Istana batu kecil di atas bukit hijau",
		badge: "Ahli Bahasa",
		badgeLine: "Kamu menyelesaikan tantangan paling sulit."
	}
];
function areaById(level) {
	const area = AREAS[level - 1];
	if (!area) throw new Error(`Area ${level} tidak ada`);
	return area;
}
var KIND_LABEL = {
	sinonim: "Sinonim",
	antonim: "Antonim",
	campuran: "Campuran",
	kalimat: "Kalimat"
};
var QUESTIONS = [
	{
		id: "s1",
		level: 1,
		kind: "sinonim",
		prompt: "Sinonim dari kata “pintar” adalah ...",
		options: [
			"Bodoh",
			"Pandai",
			"Malas",
			"Lemah"
		],
		answer: 1,
		explanation: "Pintar dan pandai sama-sama berarti cerdas atau mudah mengerti pelajaran.",
		hint: "Sinonim artinya sama. Abaikan kata yang justru berlawanan dengan pintar."
	},
	{
		id: "s2",
		level: 1,
		kind: "sinonim",
		prompt: "Sinonim dari kata “senang” adalah ...",
		options: [
			"Sedih",
			"Marah",
			"Gembira",
			"Takut"
		],
		answer: 2,
		explanation: "Senang dan gembira sama-sama berarti hati terasa nyaman dan bahagia.",
		hint: "Cari kata yang rasanya sama dengan senang, bukan perasaan yang lain."
	},
	{
		id: "s3",
		level: 1,
		kind: "sinonim",
		prompt: "Sinonim dari kata “indah” adalah ...",
		options: [
			"Jelek",
			"Kotor",
			"Elok",
			"Rusak"
		],
		answer: 2,
		explanation: "Indah dan elok sama-sama berarti bagus dipandang.",
		hint: "Soal ini meminta arti yang sama. Tiga pilihan lain artinya tidak bagus."
	},
	{
		id: "s4",
		level: 1,
		kind: "sinonim",
		prompt: "Sinonim dari kata “cepat” adalah ...",
		options: [
			"Lambat",
			"Pelan",
			"Lekas",
			"Diam"
		],
		answer: 2,
		explanation: "Cepat dan lekas sama-sama berarti tidak memakan waktu lama.",
		hint: "Lawan kata cepat adalah lambat. Kamu mencari yang artinya sama."
	},
	{
		id: "s5",
		level: 1,
		kind: "sinonim",
		prompt: "Sinonim dari kata “bantuan” adalah ...",
		options: [
			"Gangguan",
			"Masalah",
			"Pertolongan",
			"Rintangan"
		],
		answer: 2,
		explanation: "Bantuan dan pertolongan sama-sama berarti sesuatu yang meringankan orang lain.",
		hint: "Bantuan diberikan supaya orang lain lebih mudah. Cari kata yang senada."
	},
	{
		id: "s6",
		level: 1,
		kind: "sinonim",
		prompt: "Sinonim dari kata “melihat” adalah ...",
		options: [
			"Menutup",
			"Memandang",
			"Mengabaikan",
			"Melewatkan"
		],
		answer: 1,
		explanation: "Melihat dan memandang sama-sama berarti menggunakan mata untuk memperhatikan sesuatu.",
		hint: "Semua pilihan tentang mata atau perhatian. Pilih yang artinya sama, bukan yang menghindar."
	},
	{
		id: "s7",
		level: 1,
		kind: "sinonim",
		prompt: "Sinonim dari kata “pergi” adalah ...",
		options: [
			"Datang",
			"Tinggal",
			"Pulang",
			"Berangkat"
		],
		answer: 3,
		explanation: "Pergi dan berangkat sama-sama berarti meninggalkan suatu tempat.",
		hint: "Pergi berarti mulai bergerak menjauh. Datang dan pulang arahnya berbeda."
	},
	{
		id: "s8",
		level: 1,
		kind: "sinonim",
		prompt: "Sinonim dari kata “selesai” adalah ...",
		options: [
			"Mulai",
			"Awal",
			"Baru",
			"Usai"
		],
		answer: 3,
		explanation: "Selesai dan usai sama-sama berarti pekerjaan sudah berakhir.",
		hint: "Selesai ada di bagian akhir, bukan di awal kegiatan."
	},
	{
		id: "s9",
		level: 1,
		kind: "sinonim",
		prompt: "Sinonim dari kata “benar” adalah ...",
		options: [
			"Salah",
			"Keliru",
			"Palsu",
			"Betul"
		],
		answer: 3,
		explanation: "Benar dan betul sama-sama berarti sesuai dengan yang seharusnya.",
		hint: "Tiga pilihan berarti tidak tepat. Cari yang artinya sama dengan benar."
	},
	{
		id: "s10",
		level: 1,
		kind: "sinonim",
		prompt: "Sinonim dari kata “sering” adalah ...",
		options: [
			"Jarang",
			"Sekali",
			"Kerap",
			"Tidak pernah"
		],
		answer: 2,
		explanation: "Sering dan kerap sama-sama berarti terjadi berkali-kali.",
		hint: "Sering berarti banyak kali. Lawannya jarang atau tidak pernah."
	},
	{
		id: "a1",
		level: 2,
		kind: "antonim",
		prompt: "Antonim dari kata “tinggi” adalah ...",
		options: [
			"Panjang",
			"Besar",
			"Rendah",
			"Lebar"
		],
		answer: 2,
		explanation: "Tinggi dan rendah berlawanan. Panjang, besar, dan lebar bukan lawan tinggi.",
		hint: "Antonim berarti lawan kata. Bayangkan sesuatu yang tidak tinggi."
	},
	{
		id: "a2",
		level: 2,
		kind: "antonim",
		prompt: "Antonim dari kata “besar” adalah ...",
		options: [
			"Luas",
			"Kecil",
			"Tinggi",
			"Berat"
		],
		answer: 1,
		explanation: "Besar dan kecil berlawanan arti. Yang lain hanya menggambarkan ukuran yang berbeda.",
		hint: "Lawan besar adalah ukuran yang sebaliknya, bukan lebih berat atau lebih tinggi."
	},
	{
		id: "a3",
		level: 2,
		kind: "antonim",
		prompt: "Antonim dari kata “rajin” adalah ...",
		options: [
			"Tekun",
			"Giat",
			"Malas",
			"Aktif"
		],
		answer: 2,
		explanation: "Rajin dan malas berlawanan. Tekun, giat, dan aktif justru dekat artinya dengan rajin.",
		hint: "Tekun dan giat artinya mirip rajin. Kamu mencari yang berlawanan."
	},
	{
		id: "a4",
		level: 2,
		kind: "antonim",
		prompt: "Antonim dari kata “panas” adalah ...",
		options: [
			"Hangat",
			"Terik",
			"Gerah",
			"Dingin"
		],
		answer: 3,
		explanation: "Panas dan dingin berlawanan. Hangat, terik, dan gerah masih terasa panas.",
		hint: "Tiga pilihan masih terasa panas. Lawannya adalah suhu yang sebaliknya."
	},
	{
		id: "a5",
		level: 2,
		kind: "antonim",
		prompt: "Antonim dari kata “naik” adalah ...",
		options: [
			"Tinggi",
			"Atas",
			"Turun",
			"Lompat"
		],
		answer: 2,
		explanation: "Naik dan turun berlawanan arah. Tinggi dan atas bukan lawan kata naik.",
		hint: "Naik bergerak ke atas. Lawannya bergerak ke arah sebaliknya."
	},
	{
		id: "a6",
		level: 2,
		kind: "antonim",
		prompt: "Antonim dari kata “mahal” adalah ...",
		options: [
			"Mewah",
			"Murah",
			"Langka",
			"Bagus"
		],
		answer: 1,
		explanation: "Mahal dan murah berlawanan tentang harga. Mewah atau bagus bukan lawan mahal.",
		hint: "Soal ini tentang harga. Cari kata yang artinya harga tidak tinggi."
	},
	{
		id: "a7",
		level: 2,
		kind: "antonim",
		prompt: "Antonim dari kata “banyak” adalah ...",
		options: [
			"Semua",
			"Penuh",
			"Besar",
			"Sedikit"
		],
		answer: 3,
		explanation: "Banyak dan sedikit berlawanan tentang jumlah.",
		hint: "Banyak berarti jumlahnya besar. Lawannya jumlah yang kecil."
	},
	{
		id: "a8",
		level: 2,
		kind: "antonim",
		prompt: "Antonim dari kata “terang” adalah ...",
		options: [
			"Cerah",
			"Bersinar",
			"Gelap",
			"Putih"
		],
		answer: 2,
		explanation: "Terang dan gelap berlawanan. Cerah dan bersinar artinya dekat dengan terang.",
		hint: "Cerah artinya mirip terang. Kamu butuh kata yang tidak ada cahayanya."
	},
	{
		id: "a9",
		level: 2,
		kind: "antonim",
		prompt: "Antonim dari kata “berani” adalah ...",
		options: [
			"Gagah",
			"Kuat",
			"Takut",
			"Hebat"
		],
		answer: 2,
		explanation: "Berani dan takut berlawanan. Gagah, kuat, dan hebat bukan lawan berani.",
		hint: "Orang berani tidak gentar. Cari perasaan yang sebaliknya."
	},
	{
		id: "a10",
		level: 2,
		kind: "antonim",
		prompt: "Antonim dari kata “jauh” adalah ...",
		options: [
			"Panjang",
			"Lama",
			"Dekat",
			"Tinggi"
		],
		answer: 2,
		explanation: "Jauh dan dekat berlawanan tentang jarak.",
		hint: "Jauh berarti jaraknya panjang. Lawannya jarak yang singkat."
	},
	{
		id: "c1",
		level: 3,
		kind: "campuran",
		prompt: "Pasangan kata berikut yang merupakan antonim adalah ...",
		options: [
			"pintar – pandai",
			"senang – gembira",
			"besar – kecil",
			"indah – elok"
		],
		answer: 2,
		explanation: "Besar dan kecil berlawanan arti. Tiga pasangan lain adalah sinonim.",
		hint: "Antonim artinya berlawanan. Tiga pasangan di pilihan justru artinya sama."
	},
	{
		id: "c2",
		level: 3,
		kind: "campuran",
		prompt: "Pasangan kata berikut yang merupakan sinonim adalah ...",
		options: [
			"tinggi – rendah",
			"cepat – lekas",
			"panjang – pendek",
			"buka – tutup"
		],
		answer: 1,
		explanation: "Cepat dan lekas sama-sama berarti tidak lambat. Pasangan lain saling berlawanan.",
		hint: "Sinonim artinya sama. Periksa pasangan mana yang bukan lawan kata."
	},
	{
		id: "c3",
		level: 3,
		kind: "campuran",
		prompt: "Sinonim dari kata “murid” adalah ...",
		options: [
			"Guru",
			"Siswa",
			"Sekolah",
			"Kelas"
		],
		answer: 1,
		explanation: "Murid dan siswa sama-sama berarti anak yang belajar di sekolah.",
		hint: "Murid adalah orang yang belajar. Bukan tempat atau pengajarnya."
	},
	{
		id: "c4",
		level: 3,
		kind: "campuran",
		prompt: "Antonim dari kata “masuk” adalah ...",
		options: [
			"Datang",
			"Keluar",
			"Tiba",
			"Hadir"
		],
		answer: 1,
		explanation: "Masuk dan keluar berlawanan arah. Datang, tiba, dan hadir justru dekat dengan masuk.",
		hint: "Masuk berarti ke dalam. Lawannya bergerak ke luar."
	},
	{
		id: "c5",
		level: 3,
		kind: "campuran",
		prompt: "Pasangan kata yang merupakan sinonim adalah ...",
		options: [
			"hidup – mati",
			"naik – turun",
			"ingin – hendak",
			"suka – benci"
		],
		answer: 2,
		explanation: "Ingin dan hendak sama-sama berarti mau. Tiga pasangan lain berlawanan arti.",
		hint: "Cari dua kata yang bisa saling menggantikan karena artinya sama."
	},
	{
		id: "c6",
		level: 3,
		kind: "campuran",
		prompt: "Antonim dari kata “bersih” adalah ...",
		options: [
			"Rapi",
			"Kotor",
			"Wangi",
			"Licin"
		],
		answer: 1,
		explanation: "Bersih dan kotor berlawanan. Rapi, wangi, dan licin bukan lawan bersih.",
		hint: "Bayangkan baju yang tidak bersih. Itulah lawan katanya."
	},
	{
		id: "c7",
		level: 3,
		kind: "campuran",
		prompt: "Semua pasangan berikut antonim, kecuali ...",
		options: [
			"besar – kecil",
			"tinggi – rendah",
			"rajin – malas",
			"pintar – pandai"
		],
		answer: 3,
		explanation: "Pintar dan pandai adalah sinonim. Tiga pasangan lain benar-benar berlawanan.",
		hint: "Tiga pasangan berlawanan. Satu pasangan artinya sama. Itulah jawabannya."
	},
	{
		id: "c8",
		level: 3,
		kind: "campuran",
		prompt: "Kata “gelap” berantonim dengan ...",
		options: [
			"Kelam",
			"Gulita",
			"Terang",
			"Malam"
		],
		answer: 2,
		explanation: "Terang adalah lawan gelap. Kelam dan gulita justru berarti gelap juga.",
		hint: "Kelam dan gulita artinya masih gelap. Malam adalah waktu, bukan lawan kata."
	},
	{
		id: "c9",
		level: 3,
		kind: "campuran",
		prompt: "Sinonim dari kata “karena” adalah ...",
		options: [
			"Tetapi",
			"Sebab",
			"Dan",
			"Atau"
		],
		answer: 1,
		explanation: "Karena dan sebab sama-sama dipakai untuk menyatakan alasan.",
		hint: "Karena menjawab pertanyaan “mengapa”. Cari kata penghubung yang sama tugasnya."
	},
	{
		id: "c10",
		level: 3,
		kind: "campuran",
		prompt: "Pasangan yang merupakan antonim adalah ...",
		options: [
			"baik – bagus",
			"benar – betul",
			"jauh – dekat",
			"sering – kerap"
		],
		answer: 2,
		explanation: "Jauh dan dekat berlawanan. Tiga pasangan lain adalah sinonim.",
		hint: "Sebagian pasangan artinya sama. Pilih yang artinya saling berlawanan."
	},
	{
		id: "k1",
		level: 4,
		kind: "kalimat",
		prompt: "Rina adalah anak yang rajin belajar. Antonim kata “rajin” adalah ...",
		options: [
			"Tekun",
			"Malas",
			"Pintar",
			"Aktif"
		],
		answer: 1,
		explanation: "Dalam kalimat ini rajin berarti giat belajar. Lawannya adalah malas. Tekun dan aktif artinya mirip rajin.",
		hint: "Soal meminta antonim. Tekun dan aktif bukan lawan rajin."
	},
	{
		id: "k2",
		level: 4,
		kind: "kalimat",
		prompt: "Pemandangan gunung itu sangat indah. Sinonim kata “indah” adalah ...",
		options: [
			"Jelek",
			"Elok",
			"Gelap",
			"Sepi"
		],
		answer: 1,
		explanation: "Indah pada pemandangan berarti elok atau bagus dilihat.",
		hint: "Soal meminta sinonim, yaitu arti yang sama dengan indah."
	},
	{
		id: "k3",
		level: 4,
		kind: "kalimat",
		prompt: "Budi berjalan cepat menuju sekolah. Antonim kata “cepat” adalah ...",
		options: [
			"Lekas",
			"Laju",
			"Lambat",
			"Gesit"
		],
		answer: 2,
		explanation: "Lekas, laju, dan gesit dekat artinya dengan cepat. Lawan kata cepat adalah lambat.",
		hint: "Ini lawan kata. Tiga pilihan justru artinya mirip cepat."
	},
	{
		id: "k4",
		level: 4,
		kind: "kalimat",
		prompt: "Adik takut naik wahana yang tinggi. Sinonim kata “takut” adalah ...",
		options: [
			"Berani",
			"Gentar",
			"Senang",
			"Gagah"
		],
		answer: 1,
		explanation: "Gentar berarti merasa takut. Berani dan gagah justru kebalikan rasa takut.",
		hint: "Soal meminta kata yang artinya sama dengan takut, bukan lawannya."
	},
	{
		id: "k5",
		level: 4,
		kind: "kalimat",
		prompt: "Ayah memandang laut yang luas. Antonim kata “luas” adalah ...",
		options: [
			"Lebar",
			"Besar",
			"Sempit",
			"Jauh"
		],
		answer: 2,
		explanation: "Luas dan sempit berlawanan. Lebar dan besar bukan lawan luas.",
		hint: "Luas berarti lapang. Cari kata untuk tempat yang tidak lapang."
	},
	{
		id: "k6",
		level: 4,
		kind: "kalimat",
		prompt: "Nilai Dina selalu bagus. Sinonim kata “bagus” pada kalimat itu adalah ...",
		options: [
			"Buruk",
			"Baik",
			"Jelek",
			"Rusak"
		],
		answer: 1,
		explanation: "Nilai yang bagus berarti nilainya baik. Buruk, jelek, dan rusak adalah lawannya.",
		hint: "Dalam kalimat nilai, bagus berarti hasilnya baik. Jangan pilih lawan katanya."
	},
	{
		id: "k7",
		level: 4,
		kind: "kalimat",
		prompt: "Harga mainan itu mahal sekali. Antonim kata “mahal” adalah ...",
		options: [
			"Mewah",
			"Langka",
			"Murah",
			"Indah"
		],
		answer: 2,
		explanation: "Mahal dan murah berlawanan tentang harga. Mewah dan indah tidak otomatis berarti murah.",
		hint: "Perhatikan kata harga. Lawan mahal adalah harga yang rendah."
	},
	{
		id: "k8",
		level: 4,
		kind: "kalimat",
		prompt: "Ibu menolong tetangga yang kesusahan. Sinonim kata “menolong” adalah ...",
		options: [
			"Mengganggu",
			"Membantu",
			"Meninggalkan",
			"Menolak"
		],
		answer: 1,
		explanation: "Menolong dan membantu sama-sama berarti memberi bantuan.",
		hint: "Menolong berarti berbuat baik untuk orang lain. Cari kata yang sama."
	},
	{
		id: "k9",
		level: 4,
		kind: "kalimat",
		prompt: "Sungai di desa itu sangat dalam. Antonim kata “dalam” adalah ...",
		options: [
			"Lebar",
			"Dangkal",
			"Panjang",
			"Deras"
		],
		answer: 1,
		explanation: "Untuk sungai, lawan dalam adalah dangkal. Lebar, panjang, dan deras artinya berbeda.",
		hint: "Dalam pada sungai berarti dasarnya jauh. Lawannya dasar yang dekat ke permukaan."
	},
	{
		id: "k10",
		level: 4,
		kind: "kalimat",
		prompt: "Kakak sangat hemat memakai uang saku. Sinonim kata “hemat” adalah ...",
		options: [
			"Boros",
			"Irit",
			"Royal",
			"Mahal"
		],
		answer: 1,
		explanation: "Hemat dan irit sama-sama berarti berhati-hati memakai uang. Boros dan royal adalah lawannya.",
		hint: "Hemat berarti tidak boros. Boros dan royal adalah lawan kata, bukan sinonim."
	}
];
function shuffle(list) {
	const arr = [...list];
	for (let i = arr.length - 1; i > 0; i -= 1) {
		const j = Math.floor(Math.random() * (i + 1));
		const current = arr[i];
		const swap = arr[j];
		if (current === void 0 || swap === void 0) continue;
		arr[i] = swap;
		arr[j] = current;
	}
	return arr;
}
function prepare(question) {
	const mixed = shuffle(question.options.map((text, index) => ({
		text,
		ok: index === question.answer
	})));
	const answer = mixed.findIndex((item) => item.ok);
	if (answer < 0) throw new Error(`Kunci soal ${question.id} hilang`);
	return {
		...question,
		options: mixed.map((item) => item.text),
		answer
	};
}
function applyAnswer(streak, wrongStreak, correct) {
	if (correct) {
		const nextStreak = streak + 1;
		const bonus = nextStreak % 3 === 0 ? 5 : 0;
		return {
			streak: nextStreak,
			wrongStreak: 0,
			bonus,
			penalty: 0,
			delta: 10 + bonus
		};
	}
	const nextWrong = wrongStreak + 1;
	const penalty = nextWrong % 3 === 0 ? 5 : 0;
	return {
		streak: 0,
		wrongStreak: nextWrong,
		bonus: 0,
		penalty,
		delta: -penalty
	};
}
function shownScore(committed, run) {
	return committed + Math.max(0, run);
}
function percentOf(correct, total) {
	if (total <= 0) return 0;
	return Math.round(correct / total * 100);
}
function rankFor(percent) {
	if (percent >= 90) return {
		title: "Ahli Kata",
		line: "Kamu sangat menguasai sinonim dan antonim. Hebat!"
	};
	if (percent >= 75) return {
		title: "Jago Kata",
		line: "Pemahamanmu sudah kuat. Pertahankan terus!"
	};
	if (percent >= 60) return {
		title: "Penjelajah Kata",
		line: "Kamu sudah paham dasarnya. Ayo asah lagi!"
	};
	return {
		title: "Terus Berlatih",
		line: "Tidak apa-apa. Ulangi petualangan dan baca penjelasannya."
	};
}
var LETTERS = [
	"A",
	"B",
	"C",
	"D"
];
var ctx = null;
var master = null;
var musicBus = null;
var sfxBus = null;
var musicTimer = null;
var musicWanted = false;
var step = 0;
var SCALE = [
	523.25,
	587.33,
	659.25,
	783.99,
	659.25,
	587.33,
	523.25,
	440
];
function ensure() {
	if (typeof window === "undefined") return null;
	if (!ctx) {
		const AudioCtor = window.AudioContext || window.webkitAudioContext;
		if (!AudioCtor) return null;
		ctx = new AudioCtor();
		master = ctx.createGain();
		musicBus = ctx.createGain();
		sfxBus = ctx.createGain();
		master.gain.value = 1;
		musicBus.gain.value = 1;
		sfxBus.gain.value = 1;
		musicBus.connect(master);
		sfxBus.connect(master);
		master.connect(ctx.destination);
	}
	return ctx;
}
function unlockAudio() {
	const audio = ensure();
	if (audio && audio.state === "suspended") audio.resume();
}
function tone(freq, when, duration, volume, type, bus) {
	if (!ctx) return;
	const osc = ctx.createOscillator();
	const gain = ctx.createGain();
	osc.type = type;
	osc.frequency.setValueAtTime(freq, when);
	gain.gain.setValueAtTime(1e-4, when);
	gain.gain.exponentialRampToValueAtTime(Math.max(volume, 1e-4), when + .02);
	gain.gain.exponentialRampToValueAtTime(1e-4, when + duration);
	osc.connect(gain);
	gain.connect(bus);
	osc.start(when);
	osc.stop(when + duration + .03);
	osc.onended = () => {
		osc.disconnect();
		gain.disconnect();
	};
}
function playCorrect() {
	const audio = ensure();
	if (!audio || !sfxBus) return;
	const now = audio.currentTime;
	tone(523.25, now, .12, .07, "triangle", sfxBus);
	tone(659.25, now + .09, .16, .07, "triangle", sfxBus);
}
function playWrong() {
	const audio = ensure();
	if (!audio || !sfxBus) return;
	const now = audio.currentTime;
	tone(220, now, .16, .05, "sine", sfxBus);
	tone(164.81, now + .1, .2, .05, "sine", sfxBus);
}
function playBadge() {
	const audio = ensure();
	const bus = sfxBus;
	if (!audio || !bus) return;
	const now = audio.currentTime;
	[
		523.25,
		659.25,
		783.99,
		1046.5
	].forEach((freq, index) => {
		tone(freq, now + index * .11, .2, .06, "triangle", bus);
	});
}
function loopMusic() {
	if (!musicWanted || !ctx || !musicBus) return;
	const freq = SCALE[step % SCALE.length] ?? 523.25;
	step += 1;
	tone(freq, ctx.currentTime, .34, .016, "triangle", musicBus);
	if (step % 4 === 0) tone(freq / 2, ctx.currentTime, .4, .008, "sine", musicBus);
	musicTimer = window.setTimeout(loopMusic, 700);
}
function startMusic() {
	musicWanted = true;
	unlockAudio();
	if (musicTimer != null) return;
	loopMusic();
}
function stopMusic() {
	musicWanted = false;
	if (musicTimer != null) {
		window.clearTimeout(musicTimer);
		musicTimer = null;
	}
}
function setAudible(on) {
	unlockAudio();
	if (!ctx || !master) return;
	const now = ctx.currentTime;
	master.gain.cancelScheduledValues(now);
	master.gain.setTargetAtTime(on ? 1 : 1e-4, now, .03);
	if (on) startMusic();
	else stopMusic();
}
var AREA_ICONS = [
	House,
	Trees,
	Compass,
	Castle
];
var BADGE_ICONS = [
	Sparkles,
	Zap,
	Compass,
	Trophy
];
function runs() {
	return {
		deck: [],
		index: 0,
		picked: null,
		streak: 0,
		wrongStreak: 0,
		runScore: 0,
		runCorrect: 0,
		runWrong: 0,
		lastBonus: 0,
		lastPenalty: 0,
		burst: 0
	};
}
function initialState() {
	return {
		phase: "home",
		started: false,
		level: 1,
		cleared: [
			false,
			false,
			false,
			false
		],
		score: 0,
		correct: 0,
		wrong: 0,
		levelPoints: [
			0,
			0,
			0,
			0
		],
		levelHits: [
			0,
			0,
			0,
			0
		],
		practice: false,
		justAwarded: false,
		soundOn: true,
		modal: null,
		...runs()
	};
}
function unlocked(cleared, level) {
	return level === 1 || cleared[level - 2] === true;
}
function reducer(state, action) {
	switch (action.type) {
		case "start": return {
			...state,
			phase: "map",
			started: true,
			modal: null
		};
		case "ask-leave":
			if (state.phase === "quiz") return {
				...state,
				modal: action.target === "home" ? "leave-home" : "leave-map"
			};
			if (action.target === "home") return {
				...state,
				phase: "home",
				modal: null,
				...runs()
			};
			return {
				...state,
				phase: "map",
				started: true,
				modal: null,
				...runs()
			};
		case "confirm-leave":
			if (state.modal === "leave-home") return {
				...state,
				phase: "home",
				modal: null,
				...runs()
			};
			return {
				...state,
				phase: "map",
				started: true,
				modal: null,
				...runs()
			};
		case "how": return {
			...state,
			modal: "how"
		};
		case "hint": return {
			...state,
			modal: state.phase === "quiz" ? "hint" : "how"
		};
		case "ask-reset": return {
			...state,
			modal: "reset"
		};
		case "close-modal": return {
			...state,
			modal: null
		};
		case "open-level":
			if (!unlocked(state.cleared, action.level)) return state;
			if (state.cleared[action.level - 1]) return {
				...state,
				phase: "badge",
				level: action.level,
				practice: false,
				justAwarded: false,
				modal: null
			};
			return {
				...state,
				phase: "lesson",
				level: action.level,
				practice: false,
				justAwarded: false,
				modal: null
			};
		case "begin-quiz": {
			const deck = shuffle(QUESTIONS.filter((item) => item.level === state.level)).map(prepare);
			return {
				...state,
				phase: "quiz",
				...runs(),
				deck,
				modal: null
			};
		}
		case "practice": return {
			...state,
			practice: true,
			justAwarded: false,
			phase: "lesson",
			modal: null
		};
		case "pick": {
			if (state.picked !== null) return state;
			const question = state.deck[state.index];
			if (!question || action.index < 0 || action.index > 3) return state;
			const ok = action.index === question.answer;
			const result = applyAnswer(state.streak, state.wrongStreak, ok);
			return {
				...state,
				picked: action.index,
				streak: result.streak,
				wrongStreak: result.wrongStreak,
				runScore: state.runScore + result.delta,
				runCorrect: state.runCorrect + (ok ? 1 : 0),
				runWrong: state.runWrong + (ok ? 0 : 1),
				lastBonus: result.bonus,
				lastPenalty: result.penalty,
				burst: ok ? state.burst + 1 : state.burst
			};
		}
		case "next": {
			if (state.picked === null) return state;
			if (!(state.index >= state.deck.length - 1)) return {
				...state,
				index: state.index + 1,
				picked: null,
				lastBonus: 0,
				lastPenalty: 0
			};
			if (state.practice) return {
				...state,
				phase: "practice-done",
				modal: null
			};
			const slot = state.level - 1;
			const cleared = [...state.cleared];
			const levelPoints = [...state.levelPoints];
			const levelHits = [...state.levelHits];
			const earned = Math.max(0, state.runScore);
			const firstClear = !cleared[slot];
			cleared[slot] = true;
			levelPoints[slot] = earned;
			levelHits[slot] = state.runCorrect;
			const score = levelPoints.reduce((sum, points) => sum + points, 0);
			return {
				...state,
				phase: "badge",
				modal: null,
				justAwarded: true,
				cleared,
				levelPoints,
				levelHits,
				score,
				correct: firstClear ? state.correct + state.runCorrect : state.correct,
				wrong: firstClear ? state.wrong + state.runWrong : state.wrong
			};
		}
		case "finale": return {
			...state,
			phase: "finale",
			modal: null
		};
		case "reset": return {
			...initialState(),
			soundOn: state.soundOn
		};
		case "sound": return {
			...state,
			soundOn: !state.soundOn
		};
		default: return action;
	}
}
function useGame() {
	const [state, dispatch] = (0, import_react.useReducer)(reducer, void 0, initialState);
	const stateRef = (0, import_react.useRef)(state);
	stateRef.current = state;
	(0, import_react.useEffect)(() => {
		function onVis() {
			if (document.visibilityState === "visible" && stateRef.current.soundOn) unlockAudio();
		}
		document.addEventListener("visibilitychange", onVis);
		return () => document.removeEventListener("visibilitychange", onVis);
	}, []);
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			const current = stateRef.current;
			if (current.modal) {
				if (event.key === "Escape") dispatch({ type: "close-modal" });
				return;
			}
			if (current.phase !== "quiz" || current.picked !== null) return;
			const index = {
				"1": 0,
				"2": 1,
				"3": 2,
				"4": 3,
				a: 0,
				b: 1,
				c: 2,
				d: 3
			}[event.key.toLowerCase()];
			if (index === void 0) return;
			event.preventDefault();
			choose(index);
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	(0, import_react.useEffect)(() => {
		if (state.phase !== "quiz") return;
		const id = state.picked === null ? "soal-judul" : "lanjut";
		document.getElementById(id)?.focus();
	}, [
		state.phase,
		state.index,
		state.picked
	]);
	function wake() {
		unlockAudio();
		if (state.soundOn) setAudible(true);
	}
	function choose(index) {
		const current = stateRef.current;
		const question = current.deck[current.index];
		if (!question || current.picked !== null) return;
		unlockAudio();
		if (current.soundOn) {
			if (index === question.answer) playCorrect();
			else playWrong();
		}
		dispatch({
			type: "pick",
			index
		});
	}
	function finishOrNext() {
		const current = stateRef.current;
		if (current.index >= current.deck.length - 1 && !current.practice && current.soundOn) playBadge();
		dispatch({ type: "next" });
	}
	return {
		state,
		dispatch,
		wake,
		choose,
		finishOrNext
	};
}
function GameApp() {
	const { state, dispatch, wake, choose, finishOrNext } = useGame();
	const area = areaById(state.level);
	const doneCount = state.cleared.filter(Boolean).length;
	const question = state.deck[state.index];
	const totalBank = QUESTIONS.length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-line bg-paper/95 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-5xl flex-col gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/logo-sekolah.png",
							alt: "Logo SD Negeri Kalisari",
							className: "h-12 w-12 shrink-0 object-contain"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-lg leading-tight",
								children: "Petualangan Kata"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm text-muted",
								children: "SD Negeri Kalisari · Kecamatan Reban"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex flex-wrap gap-2",
						"aria-label": "Menu permainan",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
								label: "Beranda",
								icon: House,
								onClick: () => {
									wake();
									dispatch({
										type: "ask-leave",
										target: "home"
									});
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
								label: "Peta",
								icon: Map,
								onClick: () => {
									wake();
									dispatch({
										type: "ask-leave",
										target: "map"
									});
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
								label: state.phase === "quiz" ? "Petunjuk" : "Cara main",
								icon: Lightbulb,
								onClick: () => {
									wake();
									dispatch({ type: "hint" });
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
								label: state.soundOn ? "Suara nyala" : "Suara mati",
								icon: state.soundOn ? Volume2 : VolumeX,
								pressed: state.soundOn,
								onClick: () => {
									if (!state.soundOn) setAudible(true);
									else setAudible(false);
									dispatch({ type: "sound" });
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
								label: "Ulangi",
								icon: RotateCcw,
								onClick: () => {
									wake();
									dispatch({ type: "ask-reset" });
								}
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto w-full max-w-5xl px-4 py-6",
				children: [
					state.phase === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {
						started: state.started,
						onStart: () => {
							wake();
							dispatch({ type: "start" });
						},
						onHow: () => {
							wake();
							dispatch({ type: "how" });
						}
					}) : null,
					state.phase === "map" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapScreen, {
						cleared: state.cleared,
						doneCount,
						score: state.score,
						onOpen: (level) => {
							wake();
							dispatch({
								type: "open-level",
								level
							});
						},
						onFinale: () => {
							wake();
							dispatch({ type: "finale" });
						}
					}) : null,
					state.phase === "lesson" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LessonScreen, {
						level: state.level,
						practice: state.practice,
						onBegin: () => {
							wake();
							dispatch({ type: "begin-quiz" });
						}
					}) : null,
					state.phase === "quiz" && question ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuizScreen, {
						state,
						question,
						onPick: (index) => {
							wake();
							choose(index);
						},
						onNext: () => {
							wake();
							finishOrNext();
						}
					}) : null,
					state.phase === "badge" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeScreen, {
						level: state.level,
						hits: state.justAwarded ? state.runCorrect : state.levelHits[state.level - 1],
						points: state.justAwarded ? Math.max(0, state.runScore) : state.levelPoints[state.level - 1],
						fresh: state.justAwarded,
						allDone: doneCount === 4,
						onMap: () => {
							wake();
							dispatch({
								type: "ask-leave",
								target: "map"
							});
						},
						onPractice: () => {
							wake();
							dispatch({ type: "practice" });
						},
						onFinale: () => {
							wake();
							dispatch({ type: "finale" });
						}
					}) : null,
					state.phase === "practice-done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PracticeDone, {
						level: state.level,
						hits: state.runCorrect,
						points: Math.max(0, state.runScore),
						onMap: () => {
							wake();
							dispatch({
								type: "ask-leave",
								target: "map"
							});
						}
					}) : null,
					state.phase === "finale" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinaleScreen, {
						score: state.score,
						correct: state.correct,
						wrong: state.wrong,
						total: totalBank,
						onAgain: () => {
							wake();
							dispatch({ type: "reset" });
						},
						onMap: () => {
							wake();
							dispatch({
								type: "ask-leave",
								target: "map"
							});
						}
					}) : null
				]
			}),
			state.modal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				title: modalTitle(state.modal),
				onClose: () => dispatch({ type: "close-modal" }),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModalBody, {
					name: state.modal,
					hint: question?.hint ?? area.lesson,
					onClose: () => dispatch({ type: "close-modal" }),
					onReset: () => {
						if (!state.soundOn) setAudible(false);
						dispatch({ type: "reset" });
					},
					onLeave: () => dispatch({ type: "confirm-leave" })
				})
			}) : null
		]
	});
}
function NavButton({ label, icon: Icon, onClick, pressed }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		"aria-pressed": pressed,
		className: "inline-flex min-h-11 items-center gap-2 rounded-xl border border-line bg-card px-3 text-sm font-semibold text-ink active:scale-95",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-5 shrink-0",
			"aria-hidden": "true"
		}), label]
	});
}
function HomeScreen({ started, onStart, onHow }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rise grid items-center gap-6 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold tracking-wide text-amber uppercase",
				children: "Misi Sinonim & Antonim"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl leading-tight text-ink sm:text-5xl",
				children: "Petualangan Kata"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-xl text-lg text-ink",
				children: "Belajar Sinonim dan Antonim sambil Berpetualang!"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xl text-muted",
				children: "Empat area menanti: desa, hutan, jembatan, dan istana. Setiap area punya 10 soal untuk kelas 4, 5, dan 6."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-3 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onStart,
					className: "inline-flex min-h-12 items-center justify-center rounded-2xl bg-forest px-6 text-base font-semibold text-on-forest active:scale-95",
					children: started ? "Lanjutkan Petualangan" : "Mulai Petualangan"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onHow,
					className: "inline-flex min-h-12 items-center justify-center rounded-2xl border border-line bg-card px-6 text-base font-semibold text-ink active:scale-95",
					children: "Cara Bermain"
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
			className: "panel overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/art/hero.jpg",
				alt: "Dua anak membawa peta melewati desa, hutan, jembatan, dan istana",
				className: "aspect-video w-full object-cover"
			})
		})]
	});
}
function MapScreen({ cleared, doneCount, score, onOpen, onFinale }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl",
					children: "Peta Petualangan"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "Selesaikan satu area untuk membuka area berikutnya."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-full bg-card px-4 py-2 text-sm font-semibold",
					children: ["Skor: ", score]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
				value: doneCount,
				max: 4,
				label: "Progress keseluruhan"
			}),
			doneCount === 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onFinale,
				className: "mt-4 inline-flex min-h-12 w-full items-center justify-center rounded-2xl bg-amber px-5 font-semibold text-on-forest active:scale-95 sm:w-auto",
				children: "Lihat hasil petualangan"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-5 grid gap-4 lg:grid-cols-2",
				children: AREAS.map((area) => {
					const locked = !unlocked(cleared, area.id);
					const done = cleared[area.id - 1] === true;
					const Icon = AREA_ICONS[area.id - 1] ?? BookOpen;
					const status = done ? "Selesai" : locked ? "Terkunci" : "Terbuka";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "panel overflow-hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: area.image,
							alt: area.imageAlt,
							className: "aspect-video w-full object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3 p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm font-semibold text-amber",
										children: ["Area ", area.id]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-2xl",
										children: area.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: area.trail
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: clsx("inline-flex shrink-0 items-center gap-1 rounded-full px-3 py-1 text-sm font-semibold", done && "bg-good-soft text-good", !done && !locked && "bg-amber-soft text-amber", locked && "bg-paper-deep text-muted"),
									children: [
										done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
											className: "size-4",
											"aria-hidden": "true"
										}) : null,
										locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
											className: "size-4",
											"aria-hidden": "true"
										}) : null,
										!done && !locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockOpen, {
											className: "size-4",
											"aria-hidden": "true"
										}) : null,
										status
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: locked,
								onClick: () => onOpen(area.id),
								className: "inline-flex min-h-12 items-center justify-center gap-2 rounded-2xl bg-forest px-4 font-semibold text-on-forest active:scale-95 disabled:bg-paper-deep disabled:text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-5",
									"aria-hidden": "true"
								}), locked ? "Masih terkunci" : done ? "Lihat lencana" : "Mulai area"]
							})]
						})]
					}, area.id);
				})
			})
		]
	});
}
function LessonScreen({ level, practice, onBegin }) {
	const area = areaById(level);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rise mx-auto max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-semibold text-amber",
				children: ["Area ", level]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: area.name
			}),
			practice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 rounded-xl bg-amber-soft px-3 py-2 text-sm font-semibold text-amber",
				children: "Mode latihan. Skor resmi tidak berubah."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel mt-4 overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: area.image,
					alt: "",
					className: "aspect-video w-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-center gap-2 text-forest",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {
								className: "size-5",
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl text-ink",
								children: area.lessonTitle
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-lg",
							children: area.lesson
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 grid gap-2",
							children: area.examples.map((example) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "rounded-xl bg-amber-soft px-4 py-3 font-semibold text-ink",
								children: example
							}, example))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onBegin,
							className: "mt-5 inline-flex min-h-12 w-full items-center justify-center rounded-2xl bg-forest px-5 font-semibold text-on-forest active:scale-95",
							children: "Saya Mengerti, Mulai Soal"
						})
					]
				})]
			})
		]
	});
}
function QuizScreen({ state, question, onPick, onNext }) {
	const area = areaById(state.level);
	const answered = state.picked !== null;
	const correct = answered && state.picked === question.answer;
	const score = state.practice ? Math.max(0, state.runScore) : shownScore(state.score, state.runScore);
	const progress = state.index + (answered ? 1 : 0);
	const last = state.index >= state.deck.length - 1;
	const answerText = question.options[question.answer] ?? "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl",
					children: area.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-full bg-card px-3 py-1 text-sm font-semibold text-amber",
					children: KIND_LABEL[question.kind]
				})]
			}),
			state.practice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm font-semibold text-amber",
				children: "Mode latihan — skor resmi tidak berubah."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Skor",
						value: String(score)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Benar",
						value: `${state.runCorrect}/10`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Streak",
						value: String(state.streak),
						icon: state.streak > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, {
							className: "size-4 text-amber",
							"aria-hidden": "true"
						}) : null
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
				value: progress,
				max: 10,
				label: "Soal di area ini"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel relative mt-4 p-4 sm:p-6",
				children: [
					correct ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "burst",
						"aria-hidden": "true",
						children: Array.from({ length: 6 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
							className: "size-5 fill-amber",
							strokeWidth: 1.5
						}, index))
					}, state.burst) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-semibold text-muted",
						children: [
							"Soal ",
							state.index + 1,
							" dari 10"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "soal-judul",
						tabIndex: -1,
						className: "rise mt-1 font-display text-2xl leading-snug",
						children: question.prompt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						role: "group",
						"aria-label": "Pilihan jawaban",
						children: question.options.map((option, index) => {
							const letter = LETTERS[index] ?? "";
							const isAnswer = index === question.answer;
							const isPick = index === state.picked;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: answered,
								onClick: () => onPick(index),
								className: clsx("flex min-h-14 items-center gap-3 rounded-2xl border px-3 py-3 text-left text-base font-semibold active:scale-95 disabled:opacity-100", !answered && "border-line bg-card", answered && isAnswer && "border-good bg-good-soft", answered && isPick && !isAnswer && "border-bad bg-bad-soft", answered && !isAnswer && !isPick && "border-line bg-card text-muted"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: clsx("inline-flex size-11 shrink-0 items-center justify-center rounded-full", answered && isAnswer ? "bg-good text-on-forest" : "bg-paper-deep text-ink"),
										"aria-hidden": "true",
										children: letter
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1",
										children: option
									}),
									answered && isAnswer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
										className: "size-5 text-good",
										"aria-hidden": "true"
									}) : null,
									answered && isPick && !isAnswer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
										className: "size-5 text-bad",
										"aria-hidden": "true"
									}) : null
								]
							}, option);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Di komputer, tekan A sampai D untuk menjawab."
					}),
					answered ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						"aria-live": "polite",
						className: clsx("mt-4 rounded-2xl px-4 py-3", correct ? "bg-good-soft" : "bg-bad-soft"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: correct ? "🎉 Hebat! Jawabanmu benar!" : "Belum tepat. Yuk, coba pahami lagi!"
							}),
							!correct ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1",
								children: [
									"Jawaban yang benar: ",
									answerText,
									"."
								]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1",
								children: question.explanation
							}),
							state.lastBonus > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-semibold text-good",
								children: "Bonus 3 benar berturut-turut: +5 poin."
							}) : null,
							state.lastPenalty > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-semibold text-bad",
								children: "Tiga salah berturut-turut: −5 poin."
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								id: "lanjut",
								type: "button",
								onClick: onNext,
								className: "mt-3 inline-flex min-h-12 w-full items-center justify-center rounded-2xl bg-forest px-5 font-semibold text-on-forest active:scale-95 sm:w-auto",
								children: last ? state.practice ? "Selesai latihan" : "Lihat lencana" : "Lanjut"
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "sr-only",
						"aria-live": "polite",
						children: "Pilih satu jawaban."
					})
				]
			})
		]
	});
}
function Stat({ label, value, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-card px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-semibold tracking-wide text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex items-center gap-1 font-display text-2xl",
			children: [value, icon]
		})]
	});
}
function BadgeScreen({ level, hits, points, fresh, allDone, onMap, onPractice, onFinale }) {
	const area = areaById(level);
	const Icon = BADGE_ICONS[level - 1] ?? Trophy;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "rise mx-auto max-w-xl text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel px-5 py-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pop mx-auto flex size-24 items-center justify-center rounded-full bg-amber-soft text-amber",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-12",
						"aria-hidden": "true"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm font-semibold text-amber",
					children: fresh ? "Lencana baru" : "Lencana terkumpul"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl",
					children: area.badge
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: area.badgeLine
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-5 grid grid-cols-2 gap-3 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-paper px-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-sm text-muted",
							children: "Benar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "font-display text-2xl",
							children: [hits, "/10"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-paper px-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-sm text-muted",
							children: "Poin area"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-display text-2xl",
							children: points
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-col gap-3",
					children: [fresh && allDone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onFinale,
						className: "inline-flex min-h-12 items-center justify-center rounded-2xl bg-forest px-5 font-semibold text-on-forest active:scale-95",
						children: "Lihat hasil"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onMap,
						className: "inline-flex min-h-12 items-center justify-center rounded-2xl bg-forest px-5 font-semibold text-on-forest active:scale-95",
						children: "Kembali ke Peta"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onPractice,
						className: "inline-flex min-h-12 items-center justify-center rounded-2xl border border-line bg-card px-5 font-semibold active:scale-95",
						children: "Latihan lagi"
					})]
				})
			]
		})
	});
}
function PracticeDone({ level, hits, points, onMap }) {
	const area = areaById(level);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "rise mx-auto max-w-xl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "panel p-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl",
					children: "Latihan selesai"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-muted",
					children: [
						area.name,
						": ",
						hits,
						" dari 10 benar. Skor latihan ",
						points,
						" tidak mengubah nilai resmi."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onMap,
					className: "mt-5 inline-flex min-h-12 w-full items-center justify-center rounded-2xl bg-forest px-5 font-semibold text-on-forest active:scale-95",
					children: "Kembali ke Peta"
				})
			]
		})
	});
}
function FinaleScreen({ score, correct, wrong, total, onAgain, onMap }) {
	const percent = percentOf(correct, total);
	const rank = rankFor(percent);
	const RankIcon = rank.title === "Ahli Kata" ? Trophy : rank.title === "Jago Kata" ? Star : rank.title === "Penjelajah Kata" ? Compass : Sprout;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rise mx-auto max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-amber",
						children: "Perjalanan usai"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl",
						children: "Petualangan Selesai!"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: "Kamu menempuh empat area sinonim dan antonim."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel mt-5 overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/art/istana.jpg",
					alt: "",
					className: "aspect-video w-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 p-5 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultTile, {
							label: "Total skor",
							value: String(score)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultTile, {
							label: "Jawaban benar",
							value: `${correct}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultTile, {
							label: "Jawaban salah",
							value: `${wrong}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultTile, {
							label: "Persentase",
							value: `${percent}%`
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel mt-4 p-5 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pop mx-auto flex size-20 items-center justify-center rounded-full bg-amber-soft text-amber",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankIcon, {
							className: "size-10",
							"aria-hidden": "true"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-3xl",
						children: rank.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-muted",
						children: rank.line
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-6 font-display text-2xl",
				children: "Lencana yang diperoleh"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid gap-3 sm:grid-cols-2",
				children: AREAS.map((area) => {
					const Icon = BADGE_ICONS[area.id - 1] ?? Star;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "panel flex items-center gap-3 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-12 items-center justify-center rounded-full bg-amber-soft text-amber",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-6",
								"aria-hidden": "true"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted",
							children: area.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-semibold",
							children: area.badge
						})] })]
					}, area.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex flex-col gap-3 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onAgain,
					className: "inline-flex min-h-12 flex-1 items-center justify-center rounded-2xl bg-forest px-5 font-semibold text-on-forest active:scale-95",
					children: "Main Lagi"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onMap,
					className: "inline-flex min-h-12 flex-1 items-center justify-center rounded-2xl border border-line bg-card px-5 font-semibold active:scale-95",
					children: "Kembali ke Peta"
				})]
			})
		]
	});
}
function ResultTile({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-paper px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl",
			children: value
		})]
	});
}
function Bar({ value, max, label }) {
	const width = max === 0 ? 0 : Math.max(0, Math.min(100, Math.round(value / max * 100)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-1 flex justify-between gap-3 text-sm text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
			value,
			"/",
			max
		] })]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-3 overflow-hidden rounded-full bg-paper-deep",
		role: "progressbar",
		"aria-label": label,
		"aria-valuemin": 0,
		"aria-valuemax": max,
		"aria-valuenow": value,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "bar-fill",
			style: { width: `${width}%` }
		})
	})] });
}
function Modal({ title, onClose, children }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const previous = document.activeElement;
		ref.current?.focus();
		return () => {
			if (previous instanceof HTMLElement) previous.focus();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-ink/45 p-4 sm:items-center",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref,
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "modal-judul",
			tabIndex: -1,
			className: "panel max-h-[85dvh] w-full max-w-lg overflow-y-auto p-5",
			onClick: (event) => event.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "modal-judul",
					className: "font-display text-2xl",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "inline-flex size-11 items-center justify-center rounded-full bg-paper-deep",
					"aria-label": "Tutup",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
						className: "size-5",
						"aria-hidden": "true"
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children
			})]
		})
	});
}
function modalTitle(name) {
	if (name === "how") return "Cara Bermain";
	if (name === "hint") return "Petunjuk";
	if (name === "reset") return "Ulangi permainan?";
	return "Tinggalkan soal?";
}
function ModalBody({ name, hint, onClose, onReset, onLeave }) {
	if (name === "how") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
		className: "grid list-decimal gap-2 pl-5 text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Pilih area di peta. Area berikutnya terbuka setelah area sebelumnya selesai." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Baca materi singkat, lalu jawab 10 soal. Pilihan dan urutan soal diacak." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Jawaban benar mendapat 10 poin. Tiga benar berturut-turut menambah bonus 5 poin." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Tiga salah berturut-turut mengurangi 5 poin. Nyawa tidak dipakai." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Setiap area memberi satu lencana. Selesaikan Istana Kata untuk melihat hasil." })
		]
	});
	if (name === "hint") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: hint }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: onClose,
		className: "mt-4 inline-flex min-h-12 w-full items-center justify-center rounded-2xl bg-forest px-5 font-semibold text-on-forest",
		children: "Mengerti"
	})] });
	if (name === "reset") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Semua skor, lencana, dan area yang sudah selesai akan dihapus. Permainan mulai dari awal." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 flex flex-col gap-2 sm:flex-row",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onReset,
			className: "inline-flex min-h-12 flex-1 items-center justify-center rounded-2xl bg-forest px-4 font-semibold text-on-forest",
			children: "Ya, ulangi"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onClose,
			className: "inline-flex min-h-12 flex-1 items-center justify-center rounded-2xl border border-line bg-card px-4 font-semibold",
			children: "Batal"
		})]
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Jawaban di area ini belum disimpan. Kamu bisa mulai lagi dari awal area." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 flex flex-col gap-2 sm:flex-row",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onLeave,
			className: "inline-flex min-h-12 flex-1 items-center justify-center rounded-2xl bg-forest px-4 font-semibold text-on-forest",
			children: "Ya, tinggalkan"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onClose,
			className: "inline-flex min-h-12 flex-1 items-center justify-center rounded-2xl border border-line bg-card px-4 font-semibold",
			children: "Tetap di soal"
		})]
	})] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { Home as component };
